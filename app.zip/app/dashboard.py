import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime
import io
import base64


def set_custom_style():
    st.markdown("""
    <style>
        /* Main background */
        .stApp {
            background-color: #f5f5f5;
        }
        
        /* Sidebar */
        [data-testid="stSidebar"] {
            background-color: #B2BEB5 !important;
            color: white !important;
                text-color: white !important;
        }
        
        /* Titles */
        h1 {
            color: #2c3e50;
            border-bottom: 2px solid #3498db;
            padding-bottom: 10px;
        }
        
        h2 {
            color: #2c3e50;
            border-bottom: 1px solid #3498db;
            padding-bottom: 5px;
        }
        
        /* Cards */
        .stMetric {
            background-color: white;
            border-radius: 10px;
            padding: 15px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        
        /* Buttons */
        .stButton>button {
            background-color: #3498db;
            color: white;
            border-radius: 5px;
            border: none;
        }
        
        /* Tables */
        .stDataFrame {
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        
        /* Plotly chart background */
        .js-plotly-plot .plotly, .js-plotly-plot .plotly div {
            background-color: transparent !important;
        }
    </style>
    """, unsafe_allow_html=True)

def load_detection_metrics(conn):
    """Load detection metrics from database"""
    metrics = {
        'total_images': 0,
        'total_detections': 0,
        'class_distribution': [],
        'confidence_trends': []
    }
    
    try:
        cursor = conn.cursor()
        
        # Basic counts
        cursor.execute("""
            SELECT COUNT(DISTINCT image_name) as total_images, 
                   COUNT(*) as total_detections 
            FROM detections
        """)
        detection_stats = cursor.fetchone()
        if detection_stats:
            metrics['total_images'] = detection_stats[0] or 0
            metrics['total_detections'] = detection_stats[1] or 0
        
        # Class distribution
        cursor.execute("""
            SELECT object_class, COUNT(*) as count 
            FROM detections 
            GROUP BY object_class 
            ORDER BY count DESC
        """)
        metrics['class_distribution'] = cursor.fetchall() or []
        
        # Confidence trends
        cursor.execute("""
            SELECT strftime('%Y-%m-%d', timestamp) as day, 
                   COUNT(*) as daily_detections
            FROM detections
            GROUP BY day
            ORDER BY day
        """)
        metrics['confidence_trends'] = cursor.fetchall() or []
        
    except Exception as e:
        st.error(f"Error loading detection metrics: {e}")
    
    return metrics

def load_ticket_metrics(conn):
    """Load ticket metrics from database"""
    metrics = {
        'total_tickets': 0,
        'resolved_tickets': 0,
        'severity_distribution': [],
        'status_timeline': []
    }
    
    try:
        cursor = conn.cursor()
        
        # Basic counts
        cursor.execute("""
            SELECT COUNT(*) as total_tickets, 
                   SUM(CASE WHEN status = 'Resolved' THEN 1 ELSE 0 END) as resolved_tickets 
            FROM tickets
        """)
        ticket_stats = cursor.fetchone()
        if ticket_stats:
            metrics['total_tickets'] = ticket_stats[0] or 0
            metrics['resolved_tickets'] = ticket_stats[1] or 0
        
        # Severity distribution
        cursor.execute("""
            SELECT severity, COUNT(*) as count 
            FROM tickets 
            GROUP BY severity
        """)
        metrics['severity_distribution'] = cursor.fetchall() or []
        
        # Status timeline
        cursor.execute("""
            SELECT strftime('%Y-%m-%d', timestamp) as day, 
                   status, 
                   COUNT(*) as count 
            FROM tickets 
            GROUP BY day, status
            ORDER BY day
        """)
        metrics['status_timeline'] = cursor.fetchall() or []
        
    except Exception as e:
        st.error(f"Error loading ticket metrics: {e}")
    
    return metrics

def load_feedback_metrics(conn):
    """Load feedback metrics from database"""
    metrics = {
        'total_feedback': 0,
        'feedback_accuracy': {'correct': 0, 'incorrect': 0},
        'feedback_trends': [],
        'feedback_themes': {
            'classes': [],
            'counts': [],
            'correct': [],
            'incorrect': []
        }
    }
    
    try:
        cursor = conn.cursor()
        
        # Total feedback count
        cursor.execute("SELECT COUNT(*) FROM feedback")
        metrics['total_feedback'] = cursor.fetchone()[0] or 0
        
        # Accuracy counts
        cursor.execute("""
            SELECT 
                SUM(CASE WHEN corrected_label IS NULL OR corrected_label = original_class THEN 1 ELSE 0 END) as correct,
                SUM(CASE WHEN corrected_label IS NOT NULL AND corrected_label != original_class THEN 1 ELSE 0 END) as incorrect
            FROM feedback
        """)
        accuracy = cursor.fetchone()
        if accuracy:
            metrics['feedback_accuracy'] = {
                'correct': accuracy[0] or 0,
                'incorrect': accuracy[1] or 0
            }
        
        # Feedback trends
        cursor.execute("""
            SELECT 
                strftime('%Y-%m-%d', timestamp) as day,
                SUM(CASE WHEN corrected_label IS NULL OR corrected_label = original_class THEN 1 ELSE 0 END) as correct,
                SUM(CASE WHEN corrected_label IS NOT NULL AND corrected_label != original_class THEN 1 ELSE 0 END) as incorrect
            FROM feedback
            GROUP BY day
            ORDER BY day
        """)
        metrics['feedback_trends'] = cursor.fetchall() or []
        
        # Theme segmentation
        cursor.execute("""
            SELECT 
                original_class,
                COUNT(*) as count,
                SUM(CASE WHEN corrected_label IS NULL OR corrected_label = original_class THEN 1 ELSE 0 END) as correct,
                SUM(CASE WHEN corrected_label IS NOT NULL AND corrected_label != original_class THEN 1 ELSE 0 END) as incorrect
            FROM feedback
            GROUP BY original_class
            ORDER BY count DESC
        """)
        
        for row in cursor.fetchall():
            metrics['feedback_themes']['classes'].append(row[0])
            metrics['feedback_themes']['counts'].append(row[1])
            metrics['feedback_themes']['correct'].append(row[2])
            metrics['feedback_themes']['incorrect'].append(row[3])
            
    except Exception as e:
        st.error(f"Error loading feedback metrics: {e}")
    
    return metrics

def dashboard_page(detection_db, feedback_db, ticket_db):
    # st.title("📊 System Dashboard")
    # Apply custom styling
    set_custom_style()
    
    # # Add logo to sidebar
    # add_logo()
    
    # Custom header with professional styling
    st.markdown("""
    <div style="background-color: #2c3e50; padding: 5px; border-radius: 10px; margin-bottom: 30px;">
        <h1 style="color: white;text-align: center; margin: 0;">Detection Analytics Dashboard</h1>
    </div>
    """, unsafe_allow_html=True)
    
    # Load all metrics
    detection_metrics = load_detection_metrics(detection_db) if detection_db else {}
    ticket_metrics = load_ticket_metrics(ticket_db) if ticket_db else {}
    feedback_metrics = load_feedback_metrics(feedback_db) if feedback_db else {}

    # KPI CARDS
    st.subheader("Key Performance Indicators")
    cols = st.columns(4)
    with cols[0]:
        st.metric("📷 Images Processed", detection_metrics.get('total_images', 0))
    with cols[1]:
        st.metric("💬 Feedback Items", feedback_metrics.get('total_feedback', 0))
    with cols[2]:
        st.metric("🚩 Tickets Raised", ticket_metrics.get('total_tickets', 0))
    with cols[3]:
        total_tickets = ticket_metrics.get('total_tickets', 0)
        resolved_tickets = ticket_metrics.get('resolved_tickets', 0)
        resolution_rate = round((resolved_tickets/total_tickets)*100, 1) if total_tickets > 0 else 0
        st.metric("✅ Tickets Resolved", resolved_tickets, f"{resolution_rate}%")

    st.markdown("---")

    # Set default figure size for all plots
    plot_width = 600  # Custom width in pixels
    plot_height = 400  # Custom height in pixels

    # DETECTION ANALYTICS
    st.header("Detection Analytics")
    
    # Class Distribution
    if detection_metrics.get('class_distribution'):
        df_class = pd.DataFrame(detection_metrics['class_distribution'], columns=['Class', 'Count'])
        fig = px.pie(df_class, values='Count', names='Class', 
                    title='Detected Class Distribution', hole=0.3)
        fig.update_layout(
            width=300,
            height=300,
            margin=dict(l=20, r=20, t=40, b=20)  # Reduce margins
        )
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No class distribution data available")

    st.markdown("---")

    # FEEDBACK ANALYTICS
    st.header("Feedback Analysis")
    
    if feedback_metrics.get('total_feedback', 0) > 0:
        # Accuracy Overview
        col1, col2 = st.columns(2)
        with col1:
            if feedback_metrics['feedback_accuracy']['correct'] + feedback_metrics['feedback_accuracy']['incorrect'] > 0:
                fig = px.pie(
                    values=[feedback_metrics['feedback_accuracy']['correct'], 
                           feedback_metrics['feedback_accuracy']['incorrect']],
                    names=['Correct', 'Incorrect'],
                    title='Feedback Classification Accuracy',
                    color=['Correct', 'Incorrect'],
                    color_discrete_map={'Correct':'green', 'Incorrect':'red'}
                )
                st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            if feedback_metrics['feedback_themes']['classes']:
                df_themes = pd.DataFrame({
                    'Class': feedback_metrics['feedback_themes']['classes'],
                    'Total': feedback_metrics['feedback_themes']['counts'],
                    'Accuracy %': [
                        round(c/t*100, 1) if t > 0 else 0 
                        for c,t in zip(
                            feedback_metrics['feedback_themes']['correct'],
                            feedback_metrics['feedback_themes']['counts']
                        )
                    ]
                })
                fig = px.bar(
                    df_themes,
                    x='Class',
                    y='Accuracy %',
                    title='Accuracy by Object Class',
                    color='Accuracy %',
                    color_continuous_scale='RdYlGn',
                    range_color=[0, 100]
                )
                st.plotly_chart(fig, use_column_width=True)

        # Daily Trend Analysis
        st.subheader("Daily Feedback Trends")
        if feedback_metrics.get('feedback_trends'):
            df_trends = pd.DataFrame(feedback_metrics['feedback_trends'], 
                                   columns=['Date', 'Correct', 'Incorrect'])
            df_trends['Date'] = pd.to_datetime(df_trends['Date'])
            
            # Daily trends line chart
            fig_trend = go.Figure()
            
            # Correct classifications
            fig_trend.add_trace(go.Scatter(
                x=df_trends['Date'],
                y=df_trends['Correct'],
                name='Correct',
                line=dict(color='green', width=2),
                mode='lines+markers'
            ))
            
            # Incorrect classifications
            fig_trend.add_trace(go.Scatter(
                x=df_trends['Date'],
                y=df_trends['Incorrect'],
                name='Incorrect',
                line=dict(color='red', width=2),
                mode='lines+markers'
            ))
            
            fig_trend.update_layout(
                title='Daily Feedback Classification Trends',
                xaxis_title='Date',
                yaxis_title='Count',
                hovermode='x unified',
                legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
            )
            
            st.plotly_chart(fig_trend, use_container_width=True)
            
            # Daily accuracy rate
            df_trends['Accuracy'] = df_trends['Correct'] / (df_trends['Correct'] + df_trends['Incorrect']) * 100
            
            fig_accuracy = go.Figure()
            fig_accuracy.add_trace(go.Scatter(
                x=df_trends['Date'],
                y=df_trends['Accuracy'],
                name='Accuracy Rate',
                line=dict(color='blue', width=2),
                mode='lines+markers'
            ))
            
            fig_accuracy.update_layout(
                title='Daily Classification Accuracy Rate',
                xaxis_title='Date',
                yaxis_title='Accuracy (%)',
                yaxis_range=[0, 100],
                hovermode='x unified'
            )
            
            st.plotly_chart(fig_accuracy, use_container_width=True)
            
            # Stacked bar chart for daily composition
            fig_stacked = go.Figure()
            
            fig_stacked.add_trace(go.Bar(
                x=df_trends['Date'],
                y=df_trends['Correct'],
                name='Correct',
                marker_color='green'
            ))
            
            fig_stacked.add_trace(go.Bar(
                x=df_trends['Date'],
                y=df_trends['Incorrect'],
                name='Incorrect',
                marker_color='red'
            ))
            
            fig_stacked.update_layout(
                title='Daily Feedback Composition',
                xaxis_title='Date',
                yaxis_title='Count',
                barmode='stack',
                hovermode='x unified'
            )
            
            st.plotly_chart(fig_stacked, use_container_width=True)
        else:
            st.info("No feedback trends data available")
        
        # Detailed Feedback Segmentation
        st.subheader("Detailed Feedback Breakdown")
        if feedback_metrics['feedback_themes']['classes']:
            df_breakdown = pd.DataFrame({
                'Class': feedback_metrics['feedback_themes']['classes'],
                'Total': feedback_metrics['feedback_themes']['counts'],
                'Correct': feedback_metrics['feedback_themes']['correct'],
                'Incorrect': feedback_metrics['feedback_themes']['incorrect'],
                'Accuracy %': [
                    round(c/t*100, 1) if t > 0 else 0 
                    for c,t in zip(
                        feedback_metrics['feedback_themes']['correct'],
                        feedback_metrics['feedback_themes']['counts']
                    )
                ]
            })
            
            # Stacked bar chart
            fig = px.bar(
                df_breakdown,
                x='Class',
                y=['Correct', 'Incorrect'],
                title='Feedback Distribution by Class',
                color_discrete_map={'Correct':'#4CAF50', 'Incorrect':'#F44336'}
            )
            st.plotly_chart(fig, use_column_width=True)
            
            # Data table
            st.dataframe(
                df_breakdown.sort_values('Total', ascending=False),
                column_config={
                    "Accuracy %": st.column_config.ProgressColumn(
                        "Accuracy",
                        format="%.1f%%",
                        min_value=0,
                        max_value=100,
                    )
                },
                hide_index=True,
                use_container_width=True
            )
        else:
            st.info("No feedback themes data available")
    else:
        st.info("No feedback data available")

    st.markdown("---")

    # TICKET ANALYTICS
    st.header("Ticket Analytics")
    
    if ticket_metrics.get('total_tickets', 0) > 0:
        col1, col2 = st.columns(2)
        
        with col1:
            # Severity Distribution
            if ticket_metrics.get('severity_distribution'):
                df_severity = pd.DataFrame(ticket_metrics['severity_distribution'], 
                                         columns=['Severity', 'Count'])
                fig = px.pie(df_severity, values='Count', names='Severity',
                            title='Ticket Severity Distribution')
                st.plotly_chart(fig, use_column_width=True)
            else:
                st.info("No severity distribution data available")
        
        with col2:
            # Status Timeline
            if ticket_metrics.get('status_timeline'):
                df_status = pd.DataFrame(ticket_metrics['status_timeline'],
                                       columns=['Date', 'Status', 'Count'])
                df_status['Date'] = pd.to_datetime(df_status['Date'])
                
                fig = px.bar(
                    df_status,
                    x='Date',
                    y='Count',
                    color='Status',
                    title='Ticket Status Over Time',
                    barmode='stack',
                    color_discrete_map={'Open':'#FF9800', 'Resolved':'#4CAF50'}
                )
                st.plotly_chart(fig, use_column_width=True)
            else:
                st.info("No ticket timeline data available")
    else:
        st.info("No ticket data available")