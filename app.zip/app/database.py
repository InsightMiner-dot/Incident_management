import sqlite3
from sqlite3 import Error
import pandas as pd
import os
import openpyxl
from openpyxl.worksheet.table import Table, TableStyleInfo
from datetime import datetime
import streamlit as st
def create_connection(db_file):
    """Create a database connection"""
    try:
        conn = sqlite3.connect(db_file)
        conn.execute("PRAGMA foreign_keys = ON")
        return conn
    except Error as e:
        st.error(f"Database connection error: {e}")
        return None

def initialize_dbs(detection_db, feedback_db, ticket_db):
    """Initialize all database schemas"""
    initialize_detection_db(detection_db)
    initialize_feedback_db(feedback_db)
    initialize_ticket_db(ticket_db)

def initialize_detection_db(conn):
    """Initialize detection database schema"""
    try:
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS detections (
                Sl_No INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                model_name TEXT NOT NULL,
                yaml_file TEXT NOT NULL,
                image_name TEXT NOT NULL,
                object_class TEXT NOT NULL,
                confidence REAL NOT NULL
            )
        """)
        conn.commit()
    except Error as e:
        st.error(f"Detection DB init error: {e}")
        conn.rollback()

def initialize_feedback_db(conn):
    """Initialize feedback database schema"""
    try:
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS feedback (
                Sl_No INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                image_name TEXT NOT NULL,
                original_class TEXT NOT NULL,
                corrected_label TEXT,
                user_notes TEXT
            )
        """)
        conn.commit()
    except Error as e:
        st.error(f"Feedback DB init error: {e}")
        conn.rollback()

def initialize_ticket_db(conn):
    """Initialize ticket database schema"""
    try:
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS tickets (
                ticket_id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                image_name TEXT NOT NULL,
                severity TEXT NOT NULL,
                confidence REAL NOT NULL,
                object_class TEXT NOT NULL,
                description TEXT,
                status TEXT DEFAULT 'Open',
                resolved_by TEXT,
                resolution_notes TEXT,
                expected_response TEXT,
                created_by TEXT DEFAULT 'System',
                QueryRaised TEXT DEFAULT 'No'
            )
        """)
        conn.commit()
    except Error as e:
        st.error(f"Ticket DB init error: {e}")
        conn.rollback()

def save_detection_data(conn, timestamp, model_name, yaml_file, image_name, detection_details, excel_path="detections.xlsx"):
    """Save detection data to both SQL and Excel"""
    try:
        # SQL Database
        cursor = conn.cursor()
        for detail in detection_details:
            cursor.execute(
                """INSERT INTO detections 
                (timestamp, model_name, yaml_file, image_name, object_class, confidence) 
                VALUES (?,?,?,?,?,?)""",
                (timestamp, model_name, yaml_file, image_name, 
                 detail['class_name'], detail['confidence'])
            )
        conn.commit()

        excel_data = []
        for detail in detection_details:
            excel_data.append({
                "Sl_No": "DB Auto",
                "timestamp": timestamp,
                "model_name": model_name,
                "yaml_file": yaml_file,
                "image_name": image_name,
                "object_class": detail['class_name'],
                "confidence": detail['confidence']
            })
        
        # Load existing Excel data if exists
        if os.path.exists(excel_path):
            existing_df = pd.read_excel(excel_path)
            next_sl_no = existing_df['Sl_No'].max() + 1 if not existing_df.empty else 1
        else:
            existing_df = pd.DataFrame()
            next_sl_no = 1
        
        # Update Sl_No for new entries
        for i, entry in enumerate(excel_data):
            entry['Sl_No'] = next_sl_no + i
        
        # Combine and save
        new_df = pd.DataFrame(excel_data)
        combined_df = pd.concat([existing_df, new_df], ignore_index=True)
        
        # Save with proper table format
        with pd.ExcelWriter(excel_path, engine='openpyxl') as writer:
            combined_df.to_excel(writer, index=False, sheet_name='Detections')
            worksheet = writer.sheets['Detections']
            
            # Set column widths
            worksheet.column_dimensions['A'].width = 8
            worksheet.column_dimensions['B'].width = 20
            worksheet.column_dimensions['C'].width = 15
            worksheet.column_dimensions['D'].width = 20
            worksheet.column_dimensions['E'].width = 20
            worksheet.column_dimensions['F'].width = 20
            worksheet.column_dimensions['G'].width = 12
            
            # Freeze header row
            worksheet.freeze_panes = 'A2'
            
            # Add table style
            tab = Table(displayName="DetectionTable", ref=f"A1:G{len(combined_df)+1}")
            style = TableStyleInfo(
                name="TableStyleMedium9", showFirstColumn=False,
                showLastColumn=False, showRowStripes=True, showColumnStripes=False
            )
            tab.tableStyleInfo = style
            worksheet.add_table(tab)
        
        return True
    except Exception as e:
        st.error(f"Error saving detection data: {e}")
        conn.rollback()
        return False
        
def save_feedback_data(conn, timestamp, image_name, user_notes, corrected_labels, excel_path="feedback.xlsx"):
    """Save feedback data to both SQL and Excel"""
    try:
        # SQL Database
        cursor = conn.cursor()
        for orig_class, corrected_class in corrected_labels.items():
            cursor.execute(
                """INSERT INTO feedback 
                (timestamp, image_name, original_class, corrected_label, user_notes) 
                VALUES (?,?,?,?,?)""",
                (timestamp, image_name, orig_class, corrected_class, user_notes))
        conn.commit()

        # Prepare data for Excel
        excel_data = []
        for orig_class, corrected_class in corrected_labels.items():
            excel_data.append({
                "Sl_No": "DB Auto",
                "timestamp": timestamp,
                "image_name": image_name,
                "original_class": orig_class,
                "corrected_label": corrected_class,
                "user_notes": user_notes
            })
        
        # Load existing Excel data if exists
        if os.path.exists(excel_path):
            existing_df = pd.read_excel(excel_path)
            next_sl_no = existing_df['Sl_No'].max() + 1 if not existing_df.empty else 1
        else:
            existing_df = pd.DataFrame()
            next_sl_no = 1
        
        # Update Sl_No for new entries
        for i, entry in enumerate(excel_data):
            entry['Sl_No'] = next_sl_no + i
        
        # Combine and save
        new_df = pd.DataFrame(excel_data)
        combined_df = pd.concat([existing_df, new_df], ignore_index=True)
        
        # Save with proper table format
        with pd.ExcelWriter(excel_path, engine='openpyxl') as writer:
            combined_df.to_excel(writer, index=False, sheet_name='Feedback')
            worksheet = writer.sheets['Feedback']
            
            # Set column widths
            worksheet.column_dimensions['A'].width = 8
            worksheet.column_dimensions['B'].width = 20
            worksheet.column_dimensions['C'].width = 20
            worksheet.column_dimensions['D'].width = 20
            worksheet.column_dimensions['E'].width = 20
            worksheet.column_dimensions['F'].width = 30
            
            # Freeze header row
            worksheet.freeze_panes = 'A2'
            
            # Add table style
            tab = Table(displayName="FeedbackTable", ref=f"A1:F{len(combined_df)+1}")
            style = TableStyleInfo(
                name="TableStyleMedium9", showFirstColumn=False,
                showLastColumn=False, showRowStripes=True, showColumnStripes=False
            )
            tab.tableStyleInfo = style
            worksheet.add_table(tab)
        
        return True
    except Exception as e:
        st.error(f"Error saving feedback data: {e}")
        conn.rollback()
        return False

def save_ticket_data(conn, timestamp, image_name, severity, confidence, 
                    object_class, description, expected_response, 
                    created_by="System", excel_path="tickets.xlsx"):
    """Save ticket data to both SQL and Excel"""
    try:
        # SQL Database
        cursor = conn.cursor()
        cursor.execute(
            """INSERT INTO tickets 
            (timestamp, image_name, severity, confidence, object_class, 
             description, expected_response, created_by, QueryRaised) 
            VALUES (?,?,?,?,?,?,?,?,?)""",
            (timestamp, image_name, severity, confidence, object_class,
             description, expected_response, created_by, "No"))  # Added default "No" for QueryRaised
        ticket_id = cursor.lastrowid
        conn.commit()
        
        # Prepare data for Excel
        excel_data = [{
            "Ticket ID": ticket_id,
            "Timestamp": timestamp,
            "Image Name": image_name,
            "Severity": severity,
            "Confidence": confidence,
            "Object Class": object_class,
            "Description": description,
            "Status": "Open",
            "Expected Response": expected_response,
            "Created By": created_by,
            "Resolved By": "",
            "Resolution Notes": "",
            "Query Raised": "No"  # Added this new column
        }]
        
        # Load existing Excel data if exists
        if os.path.exists(excel_path):
            existing_df = pd.read_excel(excel_path)
        else:
            existing_df = pd.DataFrame()
        
        # Combine and save
        new_df = pd.DataFrame(excel_data)
        combined_df = pd.concat([existing_df, new_df], ignore_index=True)
        
        # Save with proper table format
        with pd.ExcelWriter(excel_path, engine='openpyxl') as writer:
            combined_df.to_excel(writer, index=False, sheet_name='Tickets')
            worksheet = writer.sheets['Tickets']
            
            # Set column widths
            worksheet.column_dimensions['A'].width = 10
            worksheet.column_dimensions['B'].width = 20
            worksheet.column_dimensions['C'].width = 20
            worksheet.column_dimensions['D'].width = 12
            worksheet.column_dimensions['E'].width = 12
            worksheet.column_dimensions['F'].width = 20
            worksheet.column_dimensions['G'].width = 30
            worksheet.column_dimensions['H'].width = 10
            worksheet.column_dimensions['I'].width = 20
            worksheet.column_dimensions['J'].width = 15
            worksheet.column_dimensions['K'].width = 15
            worksheet.column_dimensions['L'].width = 30
            worksheet.column_dimensions['M'].width = 15
            
            # Freeze header row
            worksheet.freeze_panes = 'A2'
            
            # Add table style
            tab = Table(displayName="TicketTable", ref=f"A1:M{len(combined_df)+1}")
            style = TableStyleInfo(
                name="TableStyleMedium9", showFirstColumn=False,
                showLastColumn=False, showRowStripes=True, showColumnStripes=False
            )
            tab.tableStyleInfo = style
            worksheet.add_table(tab)
        
        return ticket_id
    except Exception as e:
        st.error(f"Error saving ticket data: {e}")
        conn.rollback()
        return None

def update_ticket_status(conn, ticket_id, resolved_by, resolution_notes):
    """Update ticket status to resolved"""
    try:
        cursor = conn.cursor()
        cursor.execute(
            """UPDATE tickets 
            SET status = 'Resolved', 
                resolved_by = ?,
                resolution_notes = ?
            WHERE ticket_id = ?""",
            (resolved_by, resolution_notes, ticket_id)
        )
        conn.commit()
        return True
    except Exception as e:
        st.error(f"Error updating ticket: {e}")
        conn.rollback()
        return False