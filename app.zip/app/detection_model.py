import streamlit as st
import yaml
import numpy as np
from PIL import Image as PILImage
from ultralytics import YOLO
from datetime import datetime
import pandas as pd
from database import save_detection_data, save_feedback_data, save_ticket_data

def set_custom_style():
    st.markdown("""
    <style>
        /* Main background */
        .stApp {
            background-color: #f5f5f5;
        }
        
        /* Sidebar */
        [data-testid="stSidebar"] {
            background-color: #B2BEB5 !important;
            color: white !important;
                text-color: white !important;
        }
        
        /* Titles */
        h1 {
            color: #2c3e50;
            border-bottom: 2px solid #3498db;
            padding-bottom: 10px;
        }
        
        h2 {
            color: #2c3e50;
            border-bottom: 1px solid #3498db;
            padding-bottom: 5px;
        }
        
        /* Cards */
        .stMetric {
            background-color: white;
            border-radius: 10px;
            padding: 15px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        
        /* Buttons */
        .stButton>button {
            background-color: #3498db;
            color: white;
            border-radius: 5px;
            border: none;
        }
        
        /* Tables */
        .stDataFrame {
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        
        /* Plotly chart background */
        .js-plotly-plot .plotly, .js-plotly-plot .plotly div {
            background-color: transparent !important;
        }
    </style>
    """, unsafe_allow_html=True)


def load_image(image_file):
    """Load image from file"""
    img = PILImage.open(image_file)
    return np.array(img)

def resize_image(image, dest_height=150):
    """Resize image maintaining aspect ratio"""
    aspect_ratio = image.shape[1] / image.shape[0]
    new_width = int(dest_height * aspect_ratio)
    img = PILImage.fromarray(image)
    img = img.resize((new_width, dest_height), PILImage.Resampling.LANCZOS)
    return np.array(img)

# def detect_objects(image, model, confidence_level):
#     """Run object detection"""
#     results = model.predict(image, save=True, save_txt=True, save_conf=True, conf=confidence_level)
#     detect_image_path = results[0].save_dir + "/image0.jpg"
#     detect_image = PILImage.open(detect_image_path)
#     return np.array(detect_image), results

def detect_objects(image, model, confidence_level):
    """Run object detection with error handling"""
    try:
        results = model.predict(image, save=True, save_txt=True, 
                              save_conf=True, conf=confidence_level)
        
        # Return original image if no detections
        if not results or all(len(r.boxes) == 0 for r in results):
            return np.array(image), []
            
        detect_image_path = results[0].save_dir + "/image0.jpg"
        detect_image = PILImage.open(detect_image_path)
        return np.array(detect_image), results
        
    except Exception as e:
        st.error(f"Detection error: {e}")
        return np.array(image), []  # Return original image on failure

def process_detection_results(results, class_names):
    """Process detection results into structured data with null checks"""
    image_data = {}
    detection_details = []
    
    # Check if we have valid detections
    if not results or len(results) == 0:
        return image_data, detection_details
    
    for result in results:
        # Skip if no boxes detected
        if result.boxes is None or len(result.boxes) == 0:
            continue
            
        boxes = result.boxes
        # Ensure we have both cls and conf data
        if boxes.cls is not None and boxes.conf is not None:
            for cls, conf in zip(boxes.cls.tolist(), boxes.conf.tolist()):
                class_name = class_names[int(cls)]
                confidence = round(float(conf), 2)
                
                if class_name not in image_data:
                    image_data[class_name] = {'count': 0, 'confidences': []}
                
                image_data[class_name]['count'] += 1
                image_data[class_name]['confidences'].append(confidence)
                
                detection_details.append({
                    'class_name': class_name,
                    'confidence': confidence
                })
    
    return image_data, detection_details

def get_severity(confidence):
    """Determine severity based on confidence level"""
    if confidence < 0.2:
        return None
    elif 0.2 <= confidence < 0.5:
        return "Low"
    elif 0.5 <= confidence < 0.72:
        return "Medium"
    else:
        return "High"

def get_expected_response(severity):
    """Get expected response time based on severity"""
    if severity == "High":
        return "1 hour"
    elif severity == "Medium":
        return "4 hours"
    elif severity == "Low":
        return "24 hours"
    return "Manual review required"

def object_detection_page(detection_db, feedback_db, ticket_db):
    # Apply custom styling
    set_custom_style()
    # st.title("Object Detection with any model")
    st.markdown("""
    <div style="background-color: #2c3e50; padding: 1px; border-radius: 5px; margin-bottom: 10px;">
        <h1 style="color: white;text-align: center; margin: 0;">Object Detection with any model</h1>
    </div>
    """, unsafe_allow_html=True)
    
    # File uploaders
    st.sidebar.title("Upload Files")
    
    uploaded_yaml = st.sidebar.file_uploader("YAML file", type=["yaml", "yml"])
    if uploaded_yaml:
        st.session_state.yaml_file_name = uploaded_yaml.name
        try:
            yaml_content = yaml.safe_load(uploaded_yaml)
            st.session_state.class_names = yaml_content.get("class_names", [])
            if not st.session_state.class_names:
                st.sidebar.error("YAML missing class_names")
        except Exception as e:
            st.sidebar.error(f"YAML error: {e}")
    
    uploaded_model = st.sidebar.file_uploader("Model weights", type=["pt", "onnx", "bin"])
    if uploaded_model:
        st.session_state.model_name = uploaded_model.name
        model_path = f"uploaded_{st.session_state.model_name}"
        with open(model_path, "wb") as f:
            f.write(uploaded_model.getbuffer())
        try:
            st.session_state.model = YOLO(model_path)
        except Exception as e:
            st.sidebar.error(f"Model load error: {e}")
    
    # Detection settings
    st.sidebar.title("Settings")
    confidence_level = st.sidebar.slider("Confidence threshold", 0.0, 1.0, 0.5, 0.01)
    
    # Image upload - MULTIPLE FILES
    uploaded_images = st.sidebar.file_uploader("Images", type=["jpg", "jpeg", "png"], accept_multiple_files=True)
    if uploaded_images:
        st.session_state.uploaded_images = uploaded_images
    
    # Main detection interface
    if st.session_state.uploaded_images and st.session_state.model and st.session_state.class_names:
        # Navigation controls
        col1, col2, col3 = st.columns([1, 3, 1])
        with col1:
            if st.button("◀ Previous", disabled=st.session_state.current_image_index == 0):
                st.session_state.current_image_index -= 1
                st.rerun()
        with col2:
            st.markdown(f"**Image {st.session_state.current_image_index + 1} of {len(st.session_state.uploaded_images)}**", 
                       unsafe_allow_html=True)
        with col3:
            if st.button("Next ▶", disabled=st.session_state.current_image_index == len(st.session_state.uploaded_images) - 1):
                st.session_state.current_image_index += 1
                st.rerun()
        
        # Get current image
        current_image = st.session_state.uploaded_images[st.session_state.current_image_index]
        image_name = current_image.name
        image = load_image(current_image)
        resized_image = resize_image(image)

        col1, col2 = st.columns(2)
        with col1:
            st.image(resized_image, caption=f"Original: {image_name}", use_column_width=True)
    
        if st.button(f"Detect Objects in Current Image"):
            with st.spinner(f"Detecting in {image_name}..."):
                # Run detection
                detect_image, results = detect_objects(image, st.session_state.model, confidence_level)
                image_data, detection_details = process_detection_results(results, st.session_state.class_names)

                #  #Show appropriate message if no detections
                # if not detection_details:
                #     st.warning("No objects detected in this image")
                #     # Optionally show original image again
                #     col2.image(resized_image, caption="No detections", use_column_width=True)
                # else:
                #     # Show detection results
                #     col2.image(detect_image, caption="Detected Objects", use_column_width=True)
                
                # Store results for this image
                if len(st.session_state.detection_results) <= st.session_state.current_image_index:
                    st.session_state.detection_results.extend([None] * (st.session_state.current_image_index - len(st.session_state.detection_results) + 1))
                st.session_state.detection_results[st.session_state.current_image_index] = results
                
                if len(st.session_state.image_data) <= st.session_state.current_image_index:
                    st.session_state.image_data.extend([None] * (st.session_state.current_image_index - len(st.session_state.image_data) + 1))
                st.session_state.image_data[st.session_state.current_image_index] = image_data
                
                if len(st.session_state.detection_details) <= st.session_state.current_image_index:
                    st.session_state.detection_details.extend([None] * (st.session_state.current_image_index - len(st.session_state.detection_details) + 1))
                st.session_state.detection_details[st.session_state.current_image_index] = detection_details
                
                # Save to database
                timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                if detection_db:
                    success = save_detection_data(
                        detection_db,
                        timestamp,
                        st.session_state.model_name,
                        st.session_state.yaml_file_name,
                        image_name,
                        detection_details
                    )
                    if success:
                        st.success(f"Detection results for {image_name} saved!")
                    else:
                        st.error("Failed to save detection results")

            with col2:
                st.image(detect_image, caption="Detected Image", use_column_width=True)
            
            # Show results for current image
            st.write(f"## Detection Results for {image_name}")
            detection_df = pd.DataFrame(detection_details)
            st.table(detection_df)
            
            st.write("## Statistics")
            stats_data = {
                "Total Objects": len(detection_details),
                "Unique Classes": len(image_data)
            }

            if detection_details:
                stats_data.update({
                    "Min Confidence": round(min(d['confidence'] for d in detection_details), 2),
                    "Max Confidence": round(max(d['confidence'] for d in detection_details), 2)
                })
            else:
                stats_data.update({
                    "Min Confidence": "N/A",
                    "Max Confidence": "N/A"
                })

            st.table(pd.DataFrame.from_dict(stats_data, orient='index', columns=['Value']))
            
            # Ticket generation for current image
            st.write("## Ticket Generation")
            generated_tickets = []
            
            for detail in detection_details:
                confidence = detail['confidence']
                class_name = detail['class_name']
                severity = get_severity(confidence)
                
                if severity:
                    expected_response = get_expected_response(severity)
                    description = f"Automatic detection of {class_name} with confidence {confidence*100:.1f}%"
                    
                    # Generate ticket
                    ticket_id = save_ticket_data(
                        ticket_db,
                        timestamp,
                        image_name,
                        severity,
                        confidence,
                        class_name,
                        description,
                        expected_response
                    )
                    
                    if ticket_id:
                        generated_tickets.append(ticket_id)
                        st.success(f"Ticket #{ticket_id} generated for {class_name} (Confidence: {confidence*100:.1f}%)")
            
            # Store generated tickets
            st.session_state.generated_tickets.extend(generated_tickets)
            
            # For low confidence detections (<20%), prompt for manual ticket creation
            low_confidence_detections = [d for d in detection_details if d['confidence'] < 0.35]
            
            if low_confidence_detections:
                st.warning("Some detections have low confidence and require manual review:")
                
                with st.form(key=f"manual_ticket_form_{st.session_state.current_image_index}"):
                    st.table(pd.DataFrame(low_confidence_detections))
                    
                    selected_class = st.selectbox(
                        "Select detection to create ticket for",
                        [d['class_name'] for d in low_confidence_detections],
                        key=f"select_class_{st.session_state.current_image_index}"
                    )
                    
                    description = st.text_area("Issue description", key=f"desc_{st.session_state.current_image_index}")
                    severity = st.selectbox("Severity", ["Low", "Medium", "High"], key=f"severity_{st.session_state.current_image_index}")
                    user_name = st.text_input("Your name", key=f"user_{st.session_state.current_image_index}")
                    
                    if st.form_submit_button("Create Manual Ticket"):
                        selected_detection = next(d for d in low_confidence_detections if d['class_name'] == selected_class)
                        expected_response = get_expected_response(severity)
                        
                        ticket_id = save_ticket_data(
                            ticket_db,
                            datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                            image_name,
                            severity,
                            selected_detection['confidence'],
                            selected_class,
                            description,
                            expected_response,
                            user_name
                        )
                        
                        if ticket_id:
                            st.session_state.generated_tickets.append(ticket_id)
                            st.success(f"Manual Ticket #{ticket_id} created!")
        
        # If we already have results for this image, show them
        if (len(st.session_state.detection_results) > st.session_state.current_image_index and 
            st.session_state.detection_results[st.session_state.current_image_index]):
            
            results = st.session_state.detection_results[st.session_state.current_image_index]
            image_data = st.session_state.image_data[st.session_state.current_image_index]
            detection_details = st.session_state.detection_details[st.session_state.current_image_index]
            
            with col2:
                detect_image_path = results[0].save_dir + "/image0.jpg"
                detect_image = PILImage.open(detect_image_path)
                # st.image(np.array(detect_image), caption="Detected Image", use_column_width=True)
            
            # st.write(f"## Detection Results for {image_name}")
            # st.table(pd.DataFrame(detection_details))
            
        # Feedback section (per image)
        st.sidebar.title(f"Feedback for {image_name}")
        st.session_state.user_notes[st.session_state.current_image_index] = st.sidebar.text_area(
            "Your notes", 
            value=st.session_state.user_notes.get(st.session_state.current_image_index, ""),
            key=f"notes_{st.session_state.current_image_index}"
        )
        
        if len(st.session_state.image_data) > st.session_state.current_image_index:
            for class_name in st.session_state.image_data[st.session_state.current_image_index]:
                key = f"correct_{class_name}_{st.session_state.current_image_index}"
                if key not in st.session_state.corrected_labels:
                    st.session_state.corrected_labels[key] = class_name
                
                st.session_state.corrected_labels[key] = st.sidebar.text_input(
                    f"Correct '{class_name}'", 
                    value=st.session_state.corrected_labels[key],
                    key=key
                )
        
        if st.sidebar.button("Submit Feedback", key=f"feedback_{st.session_state.current_image_index}"):
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            if feedback_db:
                corrected_labels = {
                    k.split('_')[-2]: v for k, v in st.session_state.corrected_labels.items() 
                    if k.endswith(f"_{st.session_state.current_image_index}")
                }
                success = save_feedback_data(
                    feedback_db,
                    timestamp,
                    image_name,
                    st.session_state.user_notes.get(st.session_state.current_image_index, ""),
                    corrected_labels
                )
                if success:
                    st.sidebar.success("Feedback saved!")
                else:
                    st.sidebar.error("Failed to save feedback")
    
    elif not st.session_state.class_names:
        st.warning("Upload YAML with class names")
    elif not st.session_state.model:
        st.warning("Upload model weights")
    else:
        st.warning("Upload images")