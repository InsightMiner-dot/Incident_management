import streamlit as st
from PIL import Image as PILImage
import numpy as np

def load_image(image_file):
    """Load image from file"""
    img = PILImage.open(image_file)
    return np.array(img)

def resize_image(image, dest_height=100):
    """Resize image maintaining aspect ratio"""
    # aspect_ratio = image.shape[1] / image.shape[0]
    # new_width = int(dest_height * aspect_ratio)
    new_width = 100
    img = PILImage.fromarray(image)
    img = img.resize((new_width, dest_height), PILImage.Resampling.LANCZOS)
    return np.array(img)

def initialize_session_state():
    """Initialize all required session state variables"""
    if 'detection_results' not in st.session_state:
        st.session_state.detection_results = []
    if 'image_data' not in st.session_state:
        st.session_state.image_data = []
    if 'detection_details' not in st.session_state:
        st.session_state.detection_details = []
    if 'corrected_labels' not in st.session_state:
        st.session_state.corrected_labels = {}
    if 'user_notes' not in st.session_state:
        st.session_state.user_notes = {}
    if 'model' not in st.session_state:
        st.session_state.model = None
    if 'class_names' not in st.session_state:
        st.session_state.class_names = []
    if 'uploaded_images' not in st.session_state:
        st.session_state.uploaded_images = []
    if 'current_image_index' not in st.session_state:
        st.session_state.current_image_index = 0
    if 'yaml_file_name' not in st.session_state:
        st.session_state.yaml_file_name = None
    if 'model_name' not in st.session_state:
        st.session_state.model_name = None
    if 'generated_tickets' not in st.session_state:
        st.session_state.generated_tickets = []