import streamlit as st
from datetime import datetime
import pandas as pd
from database import update_ticket_status

def set_custom_style():
    st.markdown("""
    <style>
        /* Main background */
        .stApp {
            background-color: #f5f5f5;
        }
        
        /* Sidebar */
        [data-testid="stSidebar"] {
            background-color: #B2BEB5 !important;
            color: white !important;
                text-color: white !important;
        }
        
        /* Titles */
        h1 {
            color: #2c3e50;
            border-bottom: 2px solid #3498db;
            padding-bottom: 10px;
        }
        
        h2 {
            color: #2c3e50;
            border-bottom: 1px solid #3498db;
            padding-bottom: 5px;
        }
        
        /* Cards */
        .stMetric {
            background-color: white;
            border-radius: 10px;
            padding: 15px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        
        /* Buttons */
        .stButton>button {
            background-color: #3498db;
            color: white;
            border-radius: 5px;
            border: none;
        }
        
        /* Tables */
        .stDataFrame {
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        
        /* Plotly chart background */
        .js-plotly-plot .plotly, .js-plotly-plot .plotly div {
            background-color: transparent !important;
        }
    </style>
    """, unsafe_allow_html=True)


def ticket_generation_page(ticket_db):
    # st.title("🚩 Ticket Management")
    st.markdown("""
    <div style="background-color: #2c3e50; padding: 5px; border-radius: 5px; margin-bottom: 10px;">
        <h1 style="color: white;text-align: center; margin: 0;">Ticket Management</h1>
    </div>
    """, unsafe_allow_html=True)
    # View existing tickets
    st.header("Existing Tickets")
    set_custom_style()
    
    try:
        # Get all tickets from database
        cursor = ticket_db.cursor()
        cursor.execute("SELECT * FROM tickets ORDER BY timestamp DESC")
        tickets = cursor.fetchall()
        
        if not tickets:
            st.info("No tickets found")
            return
        
        for ticket in tickets:
            (ticket_id, timestamp, image_name, severity, confidence,
             object_class, description, status, resolved_by, 
             resolution_notes, expected_response, created_by,
             query_raised) = ticket
            
            # Determine color based on severity
            if severity == "High":
                color = "red"
                severity_icon = "🔴"
            elif severity == "Medium":
                color = "orange"
                severity_icon = "🟠"
            else:
                color = "blue"
                severity_icon = "🔵"
            
            # Create expandable ticket card
            with st.expander(f"🚩 Ticket #{ticket_id} - {image_name} | Severity: {severity} ({color}) | Confidence: {confidence*100:.1f}%"):
                st.markdown(f"""
                **{severity_icon} Severity:** {severity}  
                **📅 Created:** {timestamp}  
                **Query Raised:** {query_raised}
                **⏱️ Expected Response Time:** {expected_response}  
                **📝 Issue Description:** {description or 'No description provided'}  
                **🔍 Object Class:** {object_class}  
                **🔄 Status:** {status}
                """)
                
                # Resolution section (only for open tickets)
                if status == "Open":
                    st.markdown("---")
                    st.subheader("Resolve Ticket")
                    
                    with st.form(key=f"resolve_form_{ticket_id}"):
                        resolved_by_input = st.text_input("Your Name", key=f"resolved_by_{ticket_id}")
                        resolution_notes_input = st.text_area("Resolution Notes", key=f"resolution_notes_{ticket_id}")
                        
                        if st.form_submit_button("Mark as Resolved"):
                            if update_ticket_status(ticket_db, ticket_id, resolved_by_input, resolution_notes_input):
                                st.success(f"Ticket #{ticket_id} marked as resolved!")
                                st.experimental_rerun()
                            else:
                                st.error("Failed to update ticket status")
                else:
                    st.markdown(f"""
                    **✅ Resolved By:** {resolved_by}  
                    **📝 Resolution Notes:** {resolution_notes}
                    """)
    
    except Exception as e:
        st.error(f"Error loading tickets: {e}")