import streamlit as st
from database import create_connection, initialize_dbs
from detection_model import object_detection_page
from dashboard import dashboard_page
from ticket_system import ticket_generation_page
from PIL import Image
# Set page configurations
st.set_page_config(
    page_title="Defect Detection System", 
    page_icon="🚩", 
    layout="wide",
    initial_sidebar_state="expanded"
)
img = Image.open(r"D:\2025\computer_vision\logo\images.png")
img = img.resize((500, 100))  # (width, height)
st.sidebar.image(img)


# st.sidebar.image(r"D:\2025\computer_vision\logo\images.png", width=500,height=100)
# Initialize session state
if 'detection_results' not in st.session_state:
    st.session_state.detection_results = []
if 'image_data' not in st.session_state:
    st.session_state.image_data = []
if 'detection_details' not in st.session_state:
    st.session_state.detection_details = []
if 'corrected_labels' not in st.session_state:
    st.session_state.corrected_labels = {}
if 'user_notes' not in st.session_state:
    st.session_state.user_notes = {}
if 'model' not in st.session_state:
    st.session_state.model = None
if 'class_names' not in st.session_state:
    st.session_state.class_names = []
if 'uploaded_images' not in st.session_state:
    st.session_state.uploaded_images = []
if 'current_image_index' not in st.session_state:
    st.session_state.current_image_index = 0
if 'yaml_file_name' not in st.session_state:
    st.session_state.yaml_file_name = None
if 'model_name' not in st.session_state:
    st.session_state.model_name = None
if 'generated_tickets' not in st.session_state:
    st.session_state.generated_tickets = []

def main():
    # Initialize databases
    detection_db = create_connection("detection_database.db")
    feedback_db = create_connection("feedback_database.db")
    ticket_db = create_connection("ticket_database.db")
    
    initialize_dbs(detection_db, feedback_db, ticket_db)
    
    # Create page navigation
    st.sidebar.title("Navigation")
    page = st.sidebar.radio("Go to", ["Dashboard", "Object Detection", "Ticket Generation"])
    
    if page == "Dashboard":
        dashboard_page(detection_db, feedback_db, ticket_db)
    elif page == "Object Detection":
        object_detection_page(detection_db, feedback_db, ticket_db)
    elif page == "Ticket Generation":
        ticket_generation_page(ticket_db)
    
    # Clean up
    try:
        if detection_db:
            detection_db.close()
        if feedback_db:
            feedback_db.close()
        if ticket_db:
            ticket_db.close()
    except:
        pass

if __name__ == "__main__":
    main()